---
title: "Home"
language: "en"
next: "documentation.html"
---

# SkyDocs

SkyDocs is a lightweight static documentation builder with MarkDown.

[![Libraries.io for GitHub](https://img.shields.io/librariesio/github/Skyost/SkyDocs.svg?style=flat-square)](https://github.com/Skyost/SkyDocs/blob/master/pom.xml)
[![CircleCI](https://img.shields.io/circleci/project/github/Skyost/SkyDocs.svg?style=flat-square)](https://circleci.com/gh/Skyost/SkyDocs)
[![license](https://img.shields.io/github/license/Skyost/SkyDocs.svg?style=flat-square)](https://choosealicense.com/licenses/gpl-3.0/)
[![GitHub (pre-)release](https://img.shields.io/github/release/Skyost/SkyDocs/all.svg?style=flat-square)](https://github.com/Skyost/SkyDocs/releases/latest)

## Overview

SkyDocs is a software that takes your [MarkDown files](https://blog.ghost.org/markdown/) and build a complete website with some magic tricks !    
You can configure everything you want : theme, pages, menus, ...

## Features

* Lightweight
* Cross-platform (you need [Java](https://java.com/download))
* Write your documentation in MarkDown
* Use [jtwig](http://jtwig.org/documentation/reference/functions) template engine
* Host it anywhere : it's static !
* Responsive and HTML5 valid theme provided
* Generate a multi-language documentation
* Fast building
* Automatically minifies HTML, CSS and JS files in production mode.
* A lot more !

## Documentation

Everything you need to know is available in the menu <q>Documentation</q>.     
If you want a _real_ example of the possibilities of SkyDocs, well, you must know that this website has been built using SkyDocs and that its source code is
[available here](../source.zip).

## Download

If you are interested, you can download SkyDocs on [this page](documentation.html#downloading-installing).
You can also read the software's review on [Softpedia](http://www.softpedia.com/get/Others/SkyDocs.shtml).
---
title: "Créer un thème"
language: "fr"
previous: "documentation.html"
next: "a-propos.html"
---

# Créer un thème

Vous souhaitez probablement vous séparer de ce thème tout moche. Voici comment créer votre propre thème.

## Fichier page.html

Tout d'abord, vous devez avoir créé un projet. Si ceci n'est pas déjà fait, [cette page](documentation.html#creer-un-nouveau-projet) vous guidera pas à pas.
Maintenant, rendez-vous dans le répertoire de votre projet et créez un dossier appelé _theme_ (s'il est déjà créé, supprimez-le et recréez-le).

Dans le dossier du theme, vous devez posséder un fichier appelé _page.html_. Le contenu de ce fichier sera appliqué sur chaque page de votre projet (situées dans le dossier _content_ et possédant l'extension de fichier _.md_).
Souvenez-vous : SkyDocs utilise [jtwig](http://jtwig.org/documentation/reference/functions) pour formatter votre contenu HTML. Donc par exemple, si _page.html_ contient :

{% verbatim %}

```html
<!DOCTYPE html>
<html>
	<head>
		<title>{{ page.getTitle() }} | {{ project.getName() }}</title>
	</head>
	<body>
		<p>Voici le contenu de ma page nommée "{{ page.getTitle() }}" :</p>
		{{ page.getContent() }}
	</body>
</html>
```

{% endverbatim %}

Quand vous construirez votre projet, ceci sera placé sur chaque page MarkDown. Vous avez beaucoup d'autres fonctions disponibles :

{% verbatim %}

| Fonction                                              | Description                                                                                                                                                                                                                             |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ project.getName() }}`                             | Retourne le nom de votre projet comme configuré dans _plugin.yml_.                                                                                                                                                                      |
| `{{ project.getDescription() }}`                      | Retourne la description de votre projet comme configuré dans _plugin.yml_.                                                                                                                                                              |
| `{{ project.getURL() }}`                              | Retourne l'adresse URL de votre projet comme configuré dans _plugin.yml_.                                                                                                                                                               |
| `{{ project.getDefaultLanguage() }}`                  | Retourne la language par défaut de votre projet comme configuré dans _plugin.yml_.                                                                                                                                                      |
| `{{ project.getLunrSeach()() }}`                      | Retourne si oui ou non la recherche lunr doit être activée comme configuré dans _plugin.yml_.                                                                                                                                           |
| `{{ project.isDefaultOrderAlphabetical() }}`          | Retourne si oui ou non l'ordre alphabétique est l'ordre par défaut pour les pages comme configuré dans _plugin.yml_.                                                                                                                    |
| `{{ project.getPages() }}`                            | Retourne une liste itérable des pages de votre projet.                                                                                                                                                                                  |
| `{{ project.getPages(language) }}`                    | Retourne une liste itérable des pages de votre projet qui sont écrites dans la langue spécifiée.                                                                                                                                        |
| `{{ project.getMenuHTMLByLanguage(language) }}`       | Retourne le contenu HTML du menu correspondant au _language_ (langue) spécifiée. Ce contenu ne sera pas parsé avec jtwig.                                                                                                               |
| `{{ project.getField(key) }}`                         | Retourne la valeur contenue dans _project.yml_ correspondante à la _key_ (clé) spécifiée (par exemple si vous souhaitez le nom du projet, utilisez `{{ project.getField("project_name") }}`).                                           |


| Fonction                                              | Description                                                                                                                                                                                                                                                                                                                                   |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ page.getTitle() }}`                               | Retourne le titre de la page (configuré dans l'en-tête du fichier MarkDown).                                                                                                                                                                                                                                                                  |
| `{{ page.getLanguage() }}`                            | Retourne la lange de la page (configuré dans l'en-tête du fichier MarkDown).                                                                                                                                                                                                                                                                  |
| `{{ page.getContent() }}`                             | Retourne le contenu de la page (une fois converti en HTML).                                                                                                                                                                                                                                                                                   |
| `{{ page.getRootRelativeURL() }}`                     | Retourne une chaîne de caractères représentant l'adresse de la racine de votre site WEB relative à la page. Ainsi, si la page est située à `/en/creating-theme.html`, cette méthode renverra `../`.                                                                                                                                           |
| `{{ page.getRawContent() }}`                          | Retourne le contenu de la page.                                                                                                                                                                                                                                                                                                               |
| `{{ page.getRelativeURL() }}`                         | Retourne l'URL de la page.                                                                                                                                                                                                                                                                                                                    |
| `{{ page.getMenu() }}`                                | Retourne le menu relatif à cette page. Ce contenu sera parsé, vous pouvez donc utiliser les variables jtwig.                                                                                                                                                                                                                                  |
| `{{ page.getLastModificationTime() }}`                | Retourne la dernière date de modification de la page formatée grâce à la langue du système.                                                                                                                                                                                                                                                   |
| `{{ page.getLastModificationTime(format) }}`          | Retourne la dernière date de modification de la page formated avec votre format. Veuillez accéder à [cette page](https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html) pour connaître les différentes options de format.<br/>Par exemple, `{{ page.getLastModificationTime("yyyy-MM-dd") }}` peut afficher _2012-12-21_. |
| `{{ page.getLastModificationTimeForLocale(locale) }}` | Retourne la dernière date de modification de la page formatée avec la langue spécifiée. Si la langue spécifiée n'est pas valide, celle du système sera utilisée.                                                                                                                                                                              |
| `{{ page.getRawLastModificationTime() }}`             | Retourne la dernière date de modification de la page en millisecondes.                                                                                                                                                                                                                                                                        |
| `{{ page.hasPreviousPage() }}`                        | Vérifie si la page à une page précédente. La valeur sera _true_ si vous avez mis une valeur à `previous` dans l'en-tête de la page ou si vous avez activé l'ordre alphabétique par défaut pour les pages.                                                                                                                                     |
| `{{ page.getPreviousPage() }}`                        | Retourne la page précédente de la page (configuré dans l'en-tête du fichier MarkDown ou automatiquement mis si vous avez activé l'ordre alphabétique par défaut pour les pages).                                                                                                                                                              |
| `{{ page.hasNextPage() }}`                            | Vérifie si la page à une page suivante. La valeur sera _true_ si vous avez mis une valeur à `next` dans l'en-tête de la page ou si vous avez activé l'ordre alphabétique par défaut pour les pages.                                                                                                                                           |
| `{{ page.getNextPage() }}`                            | Retourne la page suivante de la page (configuré dans l'en-tête du fichier MarkDown ou automatiquement mis si vous avez activé l'ordre alphabétique par défaut pour les pages).                                                                                                                                                                |
| `{{ page.getField(key) }}`                            | Retourne la valeur contenue dans l'en-tête correspondante à la _key_ (clé) spécifiée (par exemple si vous souhaitez la langue de la page, utilisez  `{{ page.getField("language") }}`).                                                                                                                                                       |


| Fonction                                              | Description                                                                                                                                                                                                                                   |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ include_file("file.html") }}`                     | Inclut le fichier _file.html_ situé dans le dossier _theme_. Par exemple, `{{ include_file("test.html") }}` va ajouter le contenu du fichier _test.html_.                                                                                     |

Les variables `generator_name`, `generator_version` et `generator_website` sont également disponibles.

{% endverbatim %}

## Répertoire assets

Si vous souhaitez ajouter du style CSS styles ou des images, vous allez devoir créer un dossier _assets_ dans le répertoire du thème.
Une fois créé, ajoutez ce que vous souhaitez dedans : Scripts JS, du CSS et des images, etc...

Le dossier sera copié à la racine du répertoire _build_.

<div class="embed-responsive embed-responsive-16by9">
	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/C6lzYBmoVxY?showinfo=0" allowfullscreen></iframe>
</div>
$(document).ready(function() {
	localize({
		'search-box-placeholder': 'Search...',
		'paginator-previous': 'Previous page',
		'paginator-next': 'Next page'
	});
});
---
title: "Accueil"
language: "fr"
next: "documentation.html"
---

# SkyDocs

SkyDocs est un générateur de documentation léger avec MarkDown.

[![Libraries.io for GitHub](https://img.shields.io/librariesio/github/Skyost/SkyDocs.svg?style=flat-square)](https://github.com/Skyost/SkyDocs/blob/master/pom.xml)
[![CircleCI](https://img.shields.io/circleci/project/github/Skyost/SkyDocs.svg?style=flat-square)](https://circleci.com/gh/Skyost/SkyDocs)
[![license](https://img.shields.io/github/license/Skyost/SkyDocs.svg?style=flat-square)](https://choosealicense.com/licenses/gpl-3.0/)
[![GitHub (pre-)release](https://img.shields.io/github/release/Skyost/SkyDocs/all.svg?style=flat-square)](https://github.com/Skyost/SkyDocs/releases)

## Vue d'ensemble

SkyDocs est un logiciel qui prend vos [fichiers MarkDown](https://blog.ghost.org/markdown/) et génère un site web complet grâce à quelques tours de magie !    
Vous pouvez tout configurer : le thème, les pages, les menus, ...

## Fonctionnalités

* Léger
* Multisystème (vous avez besoin de [Java](https://java.com/download))
* Écrivez votre documentation en MarkDown
* Utilisez le moteur de template [jtwig](http://jtwig.org/documentation/reference/functions)
* Hébergez-le n'importe où : c'est du statique !
* Thème responsive et HTML5-valid inclus
* Générez une documentation multilangage
* Génération rapide
* Réduit automatiquement la taille des fichiers HTML, CSS et JS en mode production
* Et bien plus !

## Documentation

Tout ce que vous avez besoin de savoir est disponible dans le menu <q>Documentation</q>.    
Si vous souhaitez un exemple concret des possibilités de SkyDocs, sachez que ce site WEB a été conçu avec SkyDocs et que le code source est
[disponible au téléchargement]({{ page.getRootRelativeURL() }}assets/files/source.zip).

## Téléchargement

Si vous êtes intéressé, vous pouvez trouver les liens de téléchargement de SkyDocs sur [cette page](documentation.html#téléchargement--installation).
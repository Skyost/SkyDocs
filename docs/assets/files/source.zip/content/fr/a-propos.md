---
title: "À propos"
language: "fr"
previous: "creer-theme.html"
---

# À propos

Voici les technologies embarquées ainsi que la licence du logiciel.

## Technologies

SkyDocs embarque quelques technologies : [SnakeYAML v1.18](https://bitbucket.org/asomov/snakeyaml), [CommonMark v0.9.0](http://commonmark.org/),
[NanoHTTPD v2.3.1](https://github.com/NanoHttpd/nanohttpd), [jtwig v5.86.0](http://jtwig.org/), [YUI Compressor v2.4.8](http://yui.github.io/yuicompressor/)
et [Lunr.js v2.1.2](https://lunrjs.com).

Ce thème a été créé à l'aide de [Bootstrap v4.0.0-beta](https://getbootstrap.com/), [jQuery v3.2.1](http://jquery.com/),
[FontAwesome v4.7.0](http://fontawesome.io/), [](https://www.iconfinder.com/icons/905556/paper_print_printer_printing_icon),
[Tocbot v3.0.3](http://tscanlin.github.io/tocbot/), [jQuery.print v1.5.1](https://doersguild.github.io/jQuery.print/) et [highlight.js v9.12.0](https://highlightjs.org/).

## Licence

SkyDocs et ce thème ont été créé par [Skyost](https://www.skyost.eu) et sont disponibles sous licence [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).
L'icône originale de SkyDocs a été créée par [Kokota](https://www.iconfinder.com/icons/762531/document_file_format_text_txt_icon).
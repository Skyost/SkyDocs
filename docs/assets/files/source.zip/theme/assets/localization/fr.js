$(document).ready(function() {
	localize({
		'search-box-placeholder': 'Recherche...',
		'paginator-previous': 'Page précédente',
		'paginator-next': 'Page suivante'
	});
});
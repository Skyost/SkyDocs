---
title: "Creating your theme"
language: "en"
previous: "documentation.html"
next: "themes-gallery.html"
---

# Creating your theme

You probably want to get rid of this ugly default template. Here's how to create your own template.

## page.html file

First, you need to have created a project. If you don't know how to create your project, please check [this page](documentation.html#creating-a-new-project).
Then in your project's directory, create a folder named _theme_ (if it is already created, then delete it and re-create it).

In the theme directory, you must have a file called _page.html_. This file's content will be applied to each page of your project (located in the contents directory, with the _.md_ file extension).
Remember : SkyDocs uses [jtwig](http://jtwig.org/documentation/reference/functions) to format your HTML content. So for instance, if _page.html_ contains :

{% verbatim %}

```html
<!DOCTYPE html>
<html>
	<head>
		<title>{{ page.getTitle() }} | {{ project.getName() }}</title>
	</head>
	<body>
		<p>Here's the content of the page called "{{ page.getTitle() }}" :</p>
		{{ page.getContent() }}
	</body>
</html>
```

{% endverbatim %}

Then, when you build your project, this will be placed on each MarkDown page. You have a lot of other available functions :

{% verbatim %}

| Function                                              | Description                                                                                                                                                                                                                             |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ project.getName() }}`                             | Returns your project's name as configured in the _project.yml_.                                                                                                                                                                         |
| `{{ project.getDescription() }}`                      | Returns the description of your project as configured in the _project.yml_.                                                                                                                                                             |
| `{{ project.getURL() }}`                              | Returns the URL address of your project as configured in the _project.yml_.                                                                                                                                                             |
| `{{ project.getDefaultLanguage() }}`                  | Returns your project's default language as configured in the _project.yml_.                                                                                                                                                             |
| `{{ project.hasLunrSeach() }}`                        | Returns if lunr search should be enabled for this project as configured in the _plugin.yml_.                                                                                                                                            |
| `{{ project.isDefaultOrderAlphabetical() }}`          | Returns whether the alphabetical order is the default page order as configured in the _plugin.yml_.                                                                                                                                     |
| `{{ project.getPages() }}`                            | Returns an iterable list of your project pages.                                                                                                                                                                                         |
| `{{ project.getPages(language) }}`                    | Returns an iterable list of project pages that are written in the specified language.                                                                                                                                                   |
| `{{ project.getMenuHTMLByLanguage(language) }}`       | Returns the HTML content of the menu corresponding to the specified _language_. This content will not be parsed using jtwig.                                                                                                            |
| `{{ project.getField(key) }}`                         | Returns the field located in _project.yml_ corresponding to the _key_ (for example if you want the project's name, use `{{ project.getField("project_name") }}`).                                                                       |

| Function                                              | Description                                                                                                                                                                                                                                                                                                  |
|-------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ page.getTitle() }}`                               | Gets the title of a page (configured in the MarkDown file header).                                                                                                                                                                                                                                           |
| `{{ page.getLanguage() }}`                            | Gets the language of a page (configured in the MarkDown file header).                                                                                                                                                                                                                                        |
| `{{ page.getContent() }}`                             | Gets the content of a page (once converted in HTML).                                                                                                                                                                                                                                                         |
| `{{ page.getRawContent() }}`                          | Gets the content of a page.                                                                                                                                                                                                                                                                                  |
| `{{ page.getRootRelativeURL() }}`                     | Gets a string that represents your website root address relative to a page. For instance, if the page is located at `/en/creating-theme.html`, this method will return `../`.                                                                                                                                |
| `{{ page.getPageRelativeURL() }}`                     | Gets the relative URL of a page.                                                                                                                                                                                                                                                                             |
| `{{ page.getMenu() }}`                                | Gets the menu relative to a page. The content will be parsed, therefore you can use jtwig variables.                                                                                                                                                                                                         |
| `{{ page.getLastModificationTime() }}`                | Gets the last modification time of a page formatted with system's default locale.                                                                                                                                                                                                                            |
| `{{ page.getLastModificationTime(format) }}`          | Gets the last modification time of a page formatted with your format. Please check [this page](https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html) to know available formatting options.<br/>For example, `{{ page.getLastModificationTime("yyyy-MM-dd") }}` can output _2012-12-21_. |
| `{{ page.getLastModificationTimeForLocale(locale) }}` | Gets the last modification time of a page formatted with the specified locale. If the specified locale is not valid, the system's default locale will be used instead.                                                                                                                                       |
| `{{ page.getRawLastModificationTime() }}`             | Gets the last modification time of a page in milliseconds.                                                                                                                                                                                                                                                   |
| `{{ page.hasPreviousPage() }}`                        | Checks if a page has a previous page. This will be _true_ if you have set a value to the `previous` header key or if you have enabled the alphabetical order as the default order for pages (there must be a page before though).                                                                            |
| `{{ page.getPreviousPage() }}`                        | Gets the previous page of a page (configured in the MarkDown file header or automatically set if you have enabled the alphabetical order as the default order for pages).                                                                                                                                    |
| `{{ page.hasNextPage() }}`                            | Checks if a page has a next page. This will be _true_ if you have set a value to the `next` header key or if you have enabled the alphabetical order as the default order for pages (there must be a page after though).                                                                                     |
| `{{ page.getNextPage() }}`                            | Gets the next page of a page (configured in the MarkDown file header or automatically set if you have enabled the alphabetical order as the default order for pages).                                                                                                                                        |
| `{{ page.getField(key) }}`                            | Gets the field located in the header corresponding to the _key_ (for example if you want the page's language, use `{{ page.getField("language") }}`).                                                                                                                                                        |

| Function                                              | Description                                                                                                                                                                                                                             |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `{{ include_file("file.html") }}`                     | Includes the file _file.html_ located in the _theme_ directory. For instance, `{{ include_file("test.html") }}` will add the content of _test.html_.                                                                                    |

The variables `generator_name`, `generator_version` and `generator_website` are also available.

{% endverbatim %}

## Assets directory

If you want to add some CSS styles or images, you will have to create a directory named _assets_ in the theme folder.
Once created, put everything you want in it : JS Scripts, some CSS and images, etc...

This directory will be copied at the root of the _build_ folder.

<div class="embed-responsive embed-responsive-16by9">
	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/C6lzYBmoVxY?showinfo=0" allowfullscreen></iframe>
</div>
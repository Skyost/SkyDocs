---
title: "Themes gallery"
language: "en"
previous: "creating-theme.html"
next: "about.html"
---

# Themes gallery

On this page, you will find some themes that you can use for free in your documentations.

## Downloadable themes

Here are some themes that have been created for your documentations. To install them, just replace your _theme_ folder by the ones you can download below.

### Documentation theme

**Preview :** [Click here](../files/themes-gallery/documentation-theme.png).     
**Description :** This is the default template.     
**Author :** [Skyost](https://wwww.skyost.eu).     
**License :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Download :** You don't need to download it ! It is copied by default if there is no theme in your project directory.

### SkyDocs Material

**Preview :** [Click here](../files/themes-gallery/skydocs-material.png).     
**Description :** This is a simple material template.     
**Author :** [Skyost](https://wwww.skyost.eu).     
**License :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Download :** [Click here](../files/themes-gallery/skydocs-material.zip).

### SkyDocs Simple

**Preview :** [Click here](../files/themes-gallery/skydocs-simple.png).     
**Description :** This is a small and simple yellow theme for SkyDocs.     
**Author :** [Skyost](https://wwww.skyost.eu).     
**License :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Download :** [Click here](../files/themes-gallery/skydocs-simple.zip).

## Submit a theme

Want to provide your theme to other users ? No problem ! Just contact Skyost [here](https://www.skyost.eu/#contact) and send a message with subject `[SkyDocs] Theme submission`
and the following message body :

```bash
THEME NAME : <Your theme name>
DESCRIPTION : <A small and concise description of your theme>
AUTHOR WEBSITE : <If you want a link to your website, provide it here>
LICENSE : <Your theme license (can be empty or WTFPL)>
DOWNLOAD LINK : <A download link to your theme (any hosting, .zip archive required)>
```
---
title: "About"
language: "en"
previous: "themes-gallery.html"
---

# About

Here are the embedded technologies and the software's license.

## Technologies

SkyDocs embeds some technologies : [SnakeYAML](https://bitbucket.org/asomov/snakeyaml), [CommonMark](http://commonmark.org/),
[NanoHTTPD](https://github.com/NanoHttpd/nanohttpd), [jtwig](http://jtwig.org/), [YUI Compressor](http://yui.github.io/yuicompressor/)
[Directory Watcher](https://github.com/gmethvin/directory-watcher) and [Lunr.js](https://lunrjs.com).

This template has been created with the help of [Bootstrap](https://getbootstrap.com/), [jQuery](http://jquery.com/),
[FontAwesome](http://fontawesome.io/), [Tocbot](http://tscanlin.github.io/tocbot/),
[isInViewport.js](https://github.com/zeusdeux/isInViewport), [AnchorJS](http://bryanbraun.github.io/anchorjs/),
[jQuery.print](https://doersguild.github.io/jQuery.print/) and [highlight.js](https://highlightjs.org/).

## License

SkyDocs and this template are created by [Skyost](https://www.skyost.eu) and are licensed under [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).
The SkyDocs' original icon has been created by [Kokota](https://www.iconfinder.com/icons/762531/document_file_format_text_txt_icon).
---
title: "Documentation"
language: "en"
previous: "index.html"
next: "creating-theme.html"
---

# Documentation

This documentation has been created for **{{ generator_name }} {{ generator_version }}**. Don't forget to update it (there is a guide below) !

## Downloading & installing

Here are the steps to download and install the software.

### Downloading

First, you need to have Java installed. If you don't have it, then you can download it [here](https://java.com/download).

Then you can download the latest version of SkyDocs [here](https://github.com/Skyost/SkyDocs/releases/latest). Unzip the file where you want and that's it !

### Development builds

Development builds of this project can be acquired at the provided continuous integration server.
You can download the latest dev build <a id="circle-link" href="https://circleci.com/gh/Skyost/SkyDocs">here</a>.

[![CircleCI](https://img.shields.io/circleci/project/github/Skyost/SkyDocs.svg?style=flat-square)](https://circleci.com/gh/Skyost/SkyDocs)

### Creating a new project

To **create a new project**, go to the SkyDocs directory and run the command `java -jar SkyDocs.jar new [directory]`.
This will create a brand new project in the specified directory. If you don't specify a directory, the current location will be used instead.

You can also **manually create a new project** : first create a directory and create a file named _project.yml_ and configure it as you want (below are the available options),
then create a _menu.yml_ file (check below to see how to configure it). You also need to create a directory named _content_ (this is where you put your pages, images, ...).
That's it !

<div class="embed-responsive embed-responsive-16by9 no-print">
	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/MY32FOe8bcs?showinfo=0" allowfullscreen></iframe>
</div>

## Configuration

Once created, you have to configure your new project. Here's how to do it.

First, open the file _project.yml_, it contains your project data under an [Yaml syntax](https://en.wikipedia.org/wiki/YAML).
Here are the different keys with their corresponding description :

| Key                        | Type    | Required         | Default value                                   | Description                                                                                                                                                                                                                                                            |
|----------------------------|---------|------------------|-------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| project_name               | string  | no (but advised) | `My Documentation`                              | Your documentation title.                                                                                                                                                                                                                                              |
| project_description        | string  | no (but advised) | `Documentation built with {{ generator_name }}` | Your documentation description.                                                                                                                                                                                                                                        |
| project_url                | string  | no (but advised) | `{{ generator_website }}`                       | Your hosted documentation URL address.                                                                                                                                                                                                                                 |
| default_language           | string  | no               | `en`                                            | Your documentation default language.                                                                                                                                                                                                                                   |
| enable_lunr                | boolean | no               | `false`                                         | If you set this value to _true_, SkyDocs will include a _search.html_ page which takes a _GET_ parameter named _keywords_.<br>You have to send your keywords to this page, and [lunr](https://lunrjs.com/) will process it and will show you a list of accurate pages. |
| enable_less                | boolean | no               | `true`                                          | If you set this value to _true_, SkyDocs will parse and handle [LESS files](http://lesscss.org/). If enabled, the more LESS files you have, the longer it will take time to build your project.                                                                        |
| default_order_alphabetical | boolean | no               | `false`                                         | If you set this value to _true_, the software will order your page alphabetically (according to their file name). `page.getPreviousPage()` and `page.getNextPage()` will return values according to this order (if the corresponding header keys are not set).         |

Next, open the file _menu.yml_. It contains some menu entries :

| Key      | Type                 | Required | Description                                                                |
|----------|----------------------|----------|----------------------------------------------------------------------------|
| title    | string               | yes      | Title of the entry.                                                        |
| link     | string               | no       | Link attached to the menu.                                                 |
| weight   | integer              | no       | A page with a lower weight will be put before a page with a higher weight. |
| new_tab  | boolean              | no       | If sets to _true_, `target="_blank"` will be appended to the link.         |
| children | list of menu entries | no       | Contains the sub-entries of this menu entry.                               |

## Adding pages

If you want to add pages, images, videos, etc... head to the _content_ directory.
It is recommended to create a subdirectory per language (so for example if your website has two languages : _English_ and _French_, create two directories _en_ and _fr_).

Now, say that we want to create an _english_ page named _Hello_ with some content, for instance :

<!-- Must be RAW here, will not be rendered correctly otherwise. -->
<pre style="margin-bottom: 0;"><code class="language-ruby">---
title: "Hello"
language: "en"
---
</code></pre>

```markdown
# Hello

Nice website uh ?

**Warning ! This text will be BOLD.**
```

The first lines are the header, you can only put two things here : the title (_title_) and the language of the page (_language_).
You can enter every parameter you want. Reserved words are _title_ for the title, _language_ for the language, _previous_ for the previous page and _next_ for the next page.     
Feel free to play with all these values !

**Warning !** In a menu, you can only put a language (_language_).

## Build your documentation

When you have finished configuring your documentation, you are ready to build it !

To automatically **build** the documentation, run the file `build.bat` (or `build.sh`). To **serve** it on localhost, run the file `serve.bat` (or `serve.sh`).
Those files are created when you create a new project via the command `java -jar SkyDocs.jar new [directory]`.

You can also manually **build your documentation** with the command : `java -jar SkyDocs.jar build [directory]` (if you omit the directory, SkyDocs will try to build
the project contained in the current directory).

To manually **serve your documentation** on localhost, run this command : `java -jar SkyDocs.jar serve [directory] [port]` (as always, if you omit the directory,
SkyDocs will try to build the project contained in the current directory). The default port is 4444.

## Commands

The table below lists the available commands in SkyDocs. You can use them with the JAR `java -jar SkyDocs.jar command <arguments>` or the executable `SkyDocs command <arguments>`.

| Syntax                                                                  | Default value                                                                    | Description                                                                                                                                             |
|-------------------------------------------------------------------------|----------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| `new -directory [directory]`                                            | **directory :** current directory                                                | Creates a new documentation in the specified directory.                                                                                                 |
| `build -directory [directory]`                                          | **directory :** current directory                                                | Builds the documentation located in the specified directory. HTML, CSS and JS will be minified, therefore compil time will be bigger than with `serve`. |
| `serve -directory [directory] -port [port] -manualRebuild [true/false]` | **directory :** current directory<br>**port :** 4444<br>**manualRebuild :** true | Builds the documentation located in the specified directory and serve it on localhost with the specified port. No minification.                         |
| `update`                                                                |                                                                                  | Checks for updates.                                                                                                                                     |
| `help -command [command]`                                               | **command :** all                                                                | Shows the available commands with their description.                                                                                                    |
| `gui` (or nothing)                                                      |                                                                                  | Launches the [GUI](#gui).                                                                                                                               |

Please note that CSS and JS files will be minified when you run the _build_ command. They will **not be minified** with the _serve_ command.

## GUI

![GUI](../files/gui.png)

As of v0.5, SkyDocs comes with a _GUI_ ! As you can see, it is pretty self-explanatory : you can open your projects, build them, serve them, etc...

<script type="text/javascript">
	var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			document.getElementById('circle-link').href = JSON.parse(xmlHttp.responseText)[0].url;
		}
    }
    xmlHttp.open('GET', 'https://circleci.com/api/v1.1/project/github/Skyost/SkyDocs/latest/artifacts', true);
    xmlHttp.send(null);
</script>
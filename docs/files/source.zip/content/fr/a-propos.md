---
title: "À propos"
language: "fr"
previous: "galerie-themes.html"
---

# À propos

Voici les technologies embarquées ainsi que la licence du logiciel.

## Technologies

SkyDocs embarque quelques technologies : [SnakeYAML v1.21](https://bitbucket.org/asomov/snakeyaml), [CommonMark v0.11.0](http://commonmark.org/),
[NanoHTTPD v2.3.1](https://github.com/NanoHttpd/nanohttpd), [jtwig v5.86.1](http://jtwig.org/), [YUI Compressor v2.4.8](http://yui.github.io/yuicompressor/)
et [Lunr.js v2.1.4](https://lunrjs.com).

Ce thème a été créé à l'aide de [Bootstrap v4](https://getbootstrap.com/), [jQuery v3.2.1](http://jquery.com/),
[FontAwesome v4.7.0](http://fontawesome.io/), [Tocbot v3.0.7](http://tscanlin.github.io/tocbot/),
[isInViewport.js v3.0.0](https://github.com/zeusdeux/isInViewport), [AnchorJS.js v4.1.0](http://bryanbraun.github.io/anchorjs/),
[jQuery.print v1.5.1](https://doersguild.github.io/jQuery.print/) et [highlight.js v9.12.0](https://highlightjs.org/).

## Licence

SkyDocs et ce thème ont été créé par [Skyost](https://www.skyost.eu) et sont disponibles sous licence [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).
L'icône originale de SkyDocs a été créée par [Kokota](https://www.iconfinder.com/icons/762531/document_file_format_text_txt_icon).
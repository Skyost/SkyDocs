---
title: "À propos"
language: "fr"
previous: "galerie-themes.html"
---

# À propos

Voici les technologies embarquées ainsi que la licence du logiciel.

## Technologies

SkyDocs embarque quelques technologies : [SnakeYAML](https://bitbucket.org/asomov/snakeyaml), [CommonMark](http://commonmark.org/),
[NanoHTTPD](https://github.com/NanoHttpd/nanohttpd), [jtwig](http://jtwig.org/), [YUI Compressor](http://yui.github.io/yuicompressor/)
[Directory Watcher](https://github.com/gmethvin/directory-watcher) et [Lunr.js](https://lunrjs.com).

Ce thème a été créé à l'aide de [Bootstrap](https://getbootstrap.com/), [jQuery](http://jquery.com/),
[FontAwesome](http://fontawesome.io/), [Tocbot](http://tscanlin.github.io/tocbot/),
[isInViewport.js](https://github.com/zeusdeux/isInViewport), [AnchorJS](http://bryanbraun.github.io/anchorjs/),
[jQuery.print](https://doersguild.github.io/jQuery.print/) and [highlight.js](https://highlightjs.org/).

## Licence

SkyDocs et ce thème ont été créé par [Skyost](https://www.skyost.eu) et sont disponibles sous licence [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).
L'icône originale de SkyDocs a été créée par [Kokota](https://www.iconfinder.com/icons/762531/document_file_format_text_txt_icon).
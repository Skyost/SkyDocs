---
title: "Documentation"
language: "fr"
previous: "index.html"
next: "creer-theme.html"
---

# Documentation

Cette documentation a été écrite pour **{{ generator_name }} {{ generator_version }}**. N'oubliez pas de le mettre à jour (un guide est disponible ci-dessous) !

## Téléchargement & installation

Voici les étapes pour télécharger et installer le logiciel.

### Téléchargement

Premièrement, vous devez installer Java. Si ce n'est pas déjà fait, téléchargez-le [ici](https://java.com/download) et installez-le.

Maintenant vous pouvez télécharger la dernière version de SkyDocs [ici](https://github.com/Skyost/SkyDocs/releases/latest). Décompressez le fichier où vous le souhaitez et c'est bon !

### Builds de développement

Les builds de développement de ce projet peuvent être trouvés sur le serveur d'intégration continue fourni sur cette page.
Vous pouvez télécharger la dernière build de développement [ici](https://circleci.com/api/v1.1/project/github/Skyost/SkyDocs/latest/artifacts/0/$CIRCLE_ARTIFACTS/SkyDocs-SNAPSHOT.jar).

[![CircleCI](https://img.shields.io/circleci/project/github/Skyost/SkyDocs.svg?style=flat-square)](https://circleci.com/gh/Skyost/SkyDocs)

### Créer un nouveau projet

Pour **créer un nouveau projet**, allez dans le dossier de SkyDocs et exécutez la commande `java -jar SkyDocs.jar new [directory]`.
Ceci va créer un nouveau projet dans le répertoire spécifié. Si vous ne spécifiez pas de répertoire, le dossier courant sera utilisé à la place.

Vous pouvez également **créer un projet manuellement** : premièrement créez un dossier et créez un fichier _project.yml_ que vous configurerez comme vous le souhaitez (les options sont disponibles ci-dessous),
puis créez un fichier _menu.yml_ (allez voir ci-dessous pour voir comment le configurer). Vous aurez également besoin de créer un répertoire _content_ (c'est ici que vous mettrez vos pages, images, ...).
C'est tout !

<div class="embed-responsive embed-responsive-16by9 no-print">
	<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/MY32FOe8bcs?showinfo=0" allowfullscreen></iframe>
</div>

## Configuration

Une fois créé, vous avez besoin de configurer votre projet. Voici comment faire.

Premièrement, ouvrez le fichier _project.yml_, il contient toutes les informations de votre projet sous syntaxe [Yaml](https://fr.wikipedia.org/wiki/YAML).
Voici les différentes clés ainsi que leur description :

| Clé                        | Type    | Requis               | Valeur par défault                              | Description                                                                                                                                                                                                                                                                                   |
|----------------------------|---------|----------------------|-------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| project_name               | chaîne  | non (mais conseillé) | `My Documentation`                              | Le titre de votre documentation.                                                                                                                                                                                                                                                              |
| project_description        | chaîne  | non (mais conseillé) | `Documentation built with {{ generator_name }}` | La description de votre documentation.                                                                                                                                                                                                                                                        |
| project_url                | chaîne  | non (mais conseillé) | `{{ generator_website }}`                       | L'adresse URL de votre documentation.                                                                                                                                                                                                                                                         |
| default_language           | chaîne  | non                  | `en`                                            | La language par défaut de votre documentation.                                                                                                                                                                                                                                                |
| enable_lunr                | booléen | non                  | `false`                                         | Si vous passez cette valeur à _true_, SkyDocs va inclure une page _search.html_ qui prend _keywords_ comme paramètre _GET_.<br>Vous devez envoyer vos mots clés à cette page, et [lunr](https://lunrjs.com/) va les traiter et renvoyer la liste des pages correspondantes.                   |
| enable_less                | boolean | non                  | `true`                                          | Si vous passez cette valeur à _true_, SkyDocs va analyser et convertir les [fichiers LESS](http://lesscss.org/). Si activé, plus vous avez de fichiers LESS, plus le temps de génération de votre projet sera long.                                                                           |
| default_order_alphabetical | booléen | non                  | `false`                                         | Si vous passez cette valeur à _true_, le logiciel classera les pages par ordre alphabétique (suivant leur nom de fichier). `page.getPreviousPage()` et `page.getNextPage()` retourneront les valeurs correspondantes à ce classement (si les en-têtes correspondantes ne sont pas définies).  |

Maintenant, ouvrez le fichier _menu.yml_. Il contient quelques entrées de menu :

| Clé      | Type                    | Requis    | Description                                                                                   |
|----------|-------------------------|-----------|-----------------------------------------------------------------------------------------------|
| title    | chaîne                  | oui       | Titre de l'entée.                                                                             |
| link     | chaîne                  | non       | Lien ajouté au menu.                                                                          |
| weight   | entier                  | non       | Une page avec une petite weight se situera devant une autre page avec une plus grande weight. |
| new_tab  | booléen                 | non       | Si vous passez cette valeur à _true_, `target="_blank"` sera ajouté au lien.                  |
| children | liste d'entrées de menu | non       | Contient les sous-menus de cette entrée.                                                      |

## Ajouter des pages

Si vous souhaitez ajouter des pages, images, vidéos, etc... allez dans le dossier _content_.
Il est recommandé de créer un sous-dossier par langue (spar exemple si votre site web a deux langues : _Anglais_ et _Français_, créez deux dossiers _en_ et _fr_).

Maintenant, disons que nous voulons créer une page en _anglais_ appelée _Hello_ avec du contenu, par exemple :

<!-- Must be RAW here, will not be rendered correctly otherwise. -->
<pre style="margin-bottom: 0;"><code class="language-ruby">---
title: "Hello"
language: "en"
---
</code></pre>

```markdown
# Hello

Nice website uh ?

**Warning ! This text will be BOLD.**
```

Les premières lignes représentent l'en-tête, vous ne pouvez mettre que deux informations ici : le titre (_title_) et la langue de la page (_language_).
Vous pouvez y entrer les paramètres que vous souhaitez. Les mots réservés sont _title_ pour le titre, _language_ pour la langue, _previous_ pour la page précédente et _next_ pour la page suivante.     
N'hésitez pas à jouer avec les différentes valeurs !

**Attention !** Pour un menu, vous ne pourrez spécifier qu'une langue (_language_).

## Compiler votre documentation

Lorsque vous avez terminé de configurer votre documentation, vous êtes prêt pour la générer !

Pour générer **générer** automatiquement la documentation, exécutez le fichier `build.bat` (ou `build.sh`). Pour la **servir** sur localhost, exécutez le fichier `serve.bat` (ou `serve.sh`).
Ces fichiers sont créés lorsque vous créez une documentation avec la commande `java -jar SkyDocs.jar new [directory]`.

Vous pouvez également manuellement **construire votre documentation** avec la commande : `java -jar SkyDocs.jar build [directory]` (si vous ne spécifiez pas le répertoire, SkyDocs va essayer de générer
le projet contenu dans le dossier courant).

Pour **servir manuellement votre documentation** sur localhost, exécutez cette commande : `java -jar SkyDocs.jar serve [directory] [port]` (si vous ne spécifiez pas le répertoire,
SkyDocs va essayer de générer le projet contenu dans le dossier courant). Le port par défaut est 4444.

## Commandes

Le tableau ci-dessous liste les commandes disponibles dans SkyDocs. Vous pouvez les utiliser avec le JAR `java -jar SkyDocs.jar commande <arguments>` ou l'exécutable `SkyDocs commande <arguments>`.

| Syntaxe                                                                 | Valeur par défaut                                                              | Description                                                                                                                                              |
|-------------------------------------------------------------------------|--------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `new -directory [directory]`                                            | **directory :** dossier courant                                                | Créé une nouvelle documentation dans le dossier spécifié.                                                                                                |
| `build -directory [directory]`                                          | **directory :** dossier courant                                                | Génère la documentation contenue dans le dossier spécifié. HTML, CSS et JS seront minifiés, le temps de compilation sera donc plus long qu'avec `serve`. |
| `serve -directory [directory] -port [port] -manualRebuild [true/false]` | **directory :** dossier courant<br>**port :** 4444<br>**manualRebuild :** true | Génère la documentation contenue dans le dossier spécifié et la sert sur localhost avec le port spécifié. Pas de minification.                           |
| `update`                                                                |                                                                                | Vérifie si des mises à jours sont disponibles.                                                                                                           |
| `help -command [command]`                                               | **command :** toutes                                                           | Affiche une liste des commandes disponibles avec leur description.                                                                                       |
| `gui` (ou rien)                                                         |                                                                                | Permet de lancer l'[IHM](#ihm).                                                                                                                          |

Veuillez noter que les fichiers CSS et JS seront réduits lorsque vous exécuterez la commande _build_. Ils **ne seront pas réduits** avec la commande _serve_.

## IHM

![IHM](../files/gui.png)

À partir de la version v0.5, SkyDocs possède un _IHM_ ! Comme vous pouvez le voir c'est plutôt explicite : vous pouvez ouvrir vos projets, les compiler, les servir sur le réseau, etc...

**Attention !** Tout est en anglais cependant.
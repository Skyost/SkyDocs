---
title: "Gallerie de thèmes"
language: "fr"
previous: "creer-theme.html"
next: "a-propos.html"
---

# Gallerie de thèmes

Sur cette page, vous trouverez quelques thèmes que vous pourrez utiliser gratuitement dans vos documentations.

## Thèmes téléchargeables

Voici quelques thèmes qui ont été créés pour vos documentations. Pour les installer, vous avez juste à remplacer le dossier _theme_ par ceux que vous pouvez télécharger plus bas.

### Read the SkyDocs

**Prévisualisation :** [Cliquez-ici](../files/themes-gallery/read-the-skydocs.png).     
**Description :** Thème inspiré par [Read the Docs](https://sphinx-rtd-theme.readthedocs.io).     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** Pas besoin de le télécharger ! Il est inclus avec SkyDocs et est installé par défaut lorsque vous créez un nouveau projet.

### SkyDocs Material

**Prévisualisation :** [Cliquez-ici](../files/themes-gallery/skydocs-material.png).     
**Description :** C'est un thème Material simple.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** [Cliquez-ici](../files/themes-gallery/skydocs-material.zip).

### SkyDocs Simple

**Prévisualisation :** [Cliquez-ici](../files/themes-gallery/skydocs-simple.png).     
**Description :** C'est un petit thème jaune et simple pour SkyDocs.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** [Cliquez-ici](../files/themes-gallery/skydocs-simple.zip).

### SkyDocs Old

**Prévisualisation :** [Cliquez-ici](../files/themes-gallery/skydocs-old.png).     
**Description :** C'est le thème par défaut.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** [Cliquez-ici](../files/themes-gallery/skydocs-old.zip).

## Soumettre un thème

Vous souhaitez mettre à disposition votre thème aux autres utilisateurs ? Aucun problème ! Contactez Skyost [ici](https://www.skyost.eu/#contact) et envoyez un message
ayant pour sujet `[SkyDocs] Soumission de thème` et le corps de message suivant :

```bash
NOM DU THÈME : <Nom de votre thème>
DESCRIPTION : <Une description concise de votre thème>
SITE WEB DE L’AUTEUR : <Si vous souhaitez un lien vers votre site WEB, mettez le ici>
LICENCE : <La licence de votre thème (peut-être vide ou WTFPL)>
LIEN DE TÉLÉCHARGEMENT : <Un lien de téléchargement vers votre thème (n’importe quel hébérgeur, archive .zip requise)>
```
---
title: "Gallerie de thèmes"
language: "fr"
previous: "creer-theme.html"
next: "a-propos.html"
---

# Gallerie de thèmes

Sur cette page, vous trouverez quelques thèmes que vous pourrez utiliser gratuitement dans vos documentations.

## Thèmes téléchargeables

Voici quelques thèmes qui ont été créés pour vos documentations. Pour les installer, vous avez juste à remplacer le dossier _theme_ par ceux que vous pouvez télécharger plus bas.

### Documentation theme

**Prévisualisation :** [Click here](../files/themes-gallery/documentation-theme.png).     
**Description :** C'est le thème par défaut.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** Vous n'avez pas besoin de le télécharger ! Il est copié par défaut si aucun thème ne se situe dans le répertoire de votre projet.

### SkyDocs Material

**Prévisualisation :** [Click here](../files/themes-gallery/skydocs-material.png).     
**Description :** C'est un thème Material simple.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** [Click here](../files/themes-gallery/skydocs-material.zip).

### SkyDocs Simple

**Prévisualisation :** [Click here](../files/themes-gallery/skydocs-simple.png).     
**Description :** C'est un petit thème jaune et simple pour SkyDocs.     
**Auteur :** [Skyost](https://wwww.skyost.eu).     
**Licence :** [GNU GPL v3](https://choosealicense.com/licenses/gpl-3.0/).     
**Téléchargement :** [Click here](../files/themes-gallery/skydocs-simple.zip).

## Soumettre un thème

Vous souhaitez mettre à disposition votre thème aux autres utilisateurs ? Aucun problème ! Contactez Skyost [ici](https://www.skyost.eu/#contact) et envoyez un message
ayant pour sujet `[SkyDocs] Soumission de thème` et le corps de message suivant :

```bash
NOM DU THÈME : <Nom de votre thème>
DESCRIPTION : <Une description concise de votre thème>
SITE WEB DE L’AUTEUR : <Si vous souhaitez un lien vers votre site WEB, mettez le ici>
LICENCE : <La licence de votre thème (peut-être vide ou WTFPL)>
LIEN DE TÉLÉCHARGEMENT : <Un lien de téléchargement vers votre thème (n’importe quel hébérgeur, archive .zip requise)>
```
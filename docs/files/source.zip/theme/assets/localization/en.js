$(document).ready(function() {
	localize({
		'header form input&placeholder': 'Search...',
		'.paginator a:nth-of-type(1)&html': '<i class="fa fa-arrow-left" aria-hidden="true"></i> Previous page',
		'.paginator a:nth-of-type(2)&html': '<i class="fa fa-arrow-right" aria-hidden="true"></i> Next page'
	});
});
$(document).ready(function() {
	localize({
		'header form input&placeholder': 'Rechercher...',
		'#pagination .previous span&html': 'Précédent',
		'#pagination .next span&html': 'Suivant',
		'.links > :eq(0) a&html': 'Faire un fork sur Github',
		'.links > :eq(1) a&html': 'Mettre une étoile sur Github',
		'#navbar footer&html': 'Propulsé par <a href="https://skydocs.skyost.eu">SkyDocs</a> v0.6 Bêta.'
	});
});
$(document).ready(function() {
	localize({
		'header form input&placeholder': 'Keywords...'
	});
});
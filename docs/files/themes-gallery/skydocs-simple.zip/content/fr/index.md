---
title: "Accueil"
language: "fr"
next: "page.html"
---

# Accueil

C'est une page d'exemple pour **SkyDocs Simple** créé par [Skyost](https://www.skyost.eu).

## Lorem ipsum

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent dignissim leo eu nulla eleifend consequat ac nec mauris.
Cras sodales, nunc vitae gravida consequat, magna enim tempus erat, id hendrerit mauris diam nec augue. Etiam mattis cursus urna in elementum.
In quis auctor tellus. Aliquam consectetur in lorem id porttitor. In hac habitasse platea dictumst. Pellentesque eget nibh vel leo finibus fringilla.
Aenean mollis mi quis venenatis scelerisque. Curabitur molestie posuere orci, sit amet varius augue faucibus in. Nunc vel tincidunt elit.
Etiam efficitur eget neque eget rhoncus. Pellentesque euismod ligula ac eros viverra euismod.

## Éléments

Voici quelques éléments HTML.

### List

Voici une liste non-ordonnée :

* Premier
* Second
* Troisième

Voici une liste ordonnée :

1. Premier
2. Second
3. Troisième

### Image

Voici une belle photo en 2000x2000 :

![Beautiful picture](https://picsum.photos/2000?random)

### Blocks

<q>Wow, c'est une citation ?</q>

```java
public void code() {
	System.out.println("C'est du code.");
}
```
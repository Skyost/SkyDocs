$(document).ready(function() {
	localize({
		'#modal-search .modal-content input&placeholder': 'Keywords...',
		'#modal-search .modal-footer a&html': 'Search',
		'#modal-infos h4&html': 'Page informations',
		'#modal-infos p strong:nth-of-type(1)&html': 'Title :',
		'#modal-infos p strong:nth-of-type(2)&html': 'Language :',
		'#modal-infos p strong:nth-of-type(3)&html': 'Last modification :',
	});
});
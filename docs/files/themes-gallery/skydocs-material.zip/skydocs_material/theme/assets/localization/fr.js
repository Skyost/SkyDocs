$(document).ready(function() {
	localize({
		'#modal-search .modal-content input&placeholder': 'Mots-clés...',
		'#modal-search .modal-footer a&html': 'Rechercher',
		'#modal-infos h4&html': 'Informations sur la page',
		'#modal-infos p strong:nth-of-type(1)&html': 'Titre :',
		'#modal-infos p strong:nth-of-type(2)&html': 'Langage :',
		'#modal-infos p strong:nth-of-type(3)&html': 'Dernière modification :',
	});
});
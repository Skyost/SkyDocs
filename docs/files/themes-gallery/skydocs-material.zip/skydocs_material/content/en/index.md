---
title: "Home"
language: "en"
next: "page.html"
---

# Home

This a sample page for **SkyDocs Material** created by [Skyost](https://www.skyost.eu).

## Lorem ipsum

_Lorem ipsum dolor sit amet_, consectetur adipiscing elit. Praesent dignissim leo eu nulla eleifend consequat ac nec mauris.
Cras sodales, nunc vitae gravida consequat, magna enim tempus erat, id hendrerit mauris diam nec augue. Etiam mattis cursus urna in elementum.
In quis auctor tellus. Aliquam consectetur in lorem id porttitor. In hac habitasse platea dictumst. Pellentesque eget nibh vel leo finibus fringilla.
Aenean mollis mi quis venenatis scelerisque. Curabitur molestie posuere orci, sit amet varius augue faucibus in. Nunc vel tincidunt elit.
Etiam efficitur eget neque eget rhoncus. Pellentesque euismod ligula ac eros **viverra euismod**.

## Elements

Here are some sample HTML elements.

### List

Here is a unordered list :

* First
* Second
* Third

And this is an ordered list :

1. First
2. Second
3. Third

### Image

Here is a beautiful 2000x2000 picture :

![Beautiful picture](https://picsum.photos/2000?random)

### Blocks

<q>Wow, is this a quote ?</q>

```java
public void code() {
	System.out.println("This is code.");
}
```